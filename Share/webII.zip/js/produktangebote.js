function addProductToChart(product_name, product_id) {
    var product_counter = document.getElementById('product_counter');
    var current_amount = product_counter.innerHTML;
    product_counter.innerHTML = parseFloat(current_amount) + 1;


    new Notify({
        title: unescape("Zu Einkaufswagen hinzugef%FCgt"),
        text: product_name,
        effect: 'slide',
        speed: 300,
        status: 'success',
        autoclose: true,
        autotimeout: 3500,
        position: 'right bottom',
        gap: 20,
        distance: 70
    })


    document.cookie = "product_id_" + product_id + "=" + "1";
}

