function openForm() {

}
	
function closeForm() {
	document.getElementById("LoginForm").style.display = "none";
}

function checkIfMail(inputEmailId) {
	var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
	
	if(document.getElementById("emailFeld1").value.match(mailformat))
	{
		alert("E-Mail korrekt.");
		alert.closeForm;
	}
	else
	{
		alert("E-Mail inkorrekt");
	}
	checkIfMail1EqMail2();
}

function checkifMail1EqMail2()
{
	if(document.getElementById("emailFeld2").value.match(document.getElementById("emailFeld1").value))
	{
		alert("E-Mails korrekt.");
	}
	else
	{
		alert("E-Mails verschieden");
		document.getElementById("emailFeld1").style.borderColor("red");
		document.getElementById("emailFeld2").style.borderColor("red");
		
	}
}